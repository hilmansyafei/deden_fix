package com.denisha.lambung;

import android.view.View;

/**
 * Created by USER on 6/17/2016.
 */

public interface itemClickListener {
    void onClick(View view, int position);
}